import numpy as np

reveal_type(np.uint128())
reveal_type(np.uint256())

reveal_type(np.int128())
reveal_type(np.int256())

reveal_type(np.float80())
reveal_type(np.float96())
reveal_type(np.float128())
reveal_type(np.float256())

reveal_type(np.complex160())
reveal_type(np.complex192())
reveal_type(np.complex256())
reveal_type(np.complex512())
